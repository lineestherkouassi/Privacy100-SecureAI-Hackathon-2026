class WeakMLP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  net : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.WeakMLP,
    x: Tensor) -> Tensor:
    net = self.net
    _0 = torch.squeeze((net).forward(x, ), -1)
    return _0
